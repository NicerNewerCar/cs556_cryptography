#include <string>

std::string brute_force(const std::string &cipher_fname,
                        const std::string &pub_fname);
